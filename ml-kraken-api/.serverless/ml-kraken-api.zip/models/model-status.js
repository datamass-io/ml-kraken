
module.exports = {
    STOPPED: 'STOPPED',
    RUNNING: 'RUNNING',
    PENDING: 'PENDING',
    ERROR: 'ERROR'
};