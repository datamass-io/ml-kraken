## Build 

``` 
npm install
sls dynamodb install
serverless offline start
```
