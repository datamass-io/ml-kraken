{
    type: "object"
    properties:
        name:
            type: "string"
        version:
            type: "string"
}
